import java.util.Scanner;

public class Main {
//4 Пользователь вводит строку. Посчитайте количество слов в строке и выведите в консоль.
// Разделителем между словами считать только пробел. Если в строке есть слова, которые длиннее трёх символов, то вывести эти слова в консоль.
    public static void main(String[] args) {
        System.out.println("Введите строку из нескольких слов: ");
        Scanner scr = new Scanner(System.in);
        String userText = scr.nextLine();
        String [] words = userText.split(" ");
        int wordCount = words.length;
        System.out.println("Количество слов в строке: " + wordCount);
        System.out.print("Слова имеющие больше трёх символов: ");
        for (String word : words) {
            if (word.length() > 3) {
                System.out.print(word + " ");

            }
        }
    }
}