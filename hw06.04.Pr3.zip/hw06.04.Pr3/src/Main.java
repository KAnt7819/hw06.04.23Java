import java.util.Arrays;
import java.util.Scanner;

public class Main {

//3 Пользователь вводит строку. Разместите буквы в строке по алфавиту и выведите в консоль

    public static void main(String[] args) {
        System.out.println("Ведите текст: ");
        Scanner scr = new Scanner(System.in);
        String userString = scr.nextLine(); // принимаем текст из сканера
        char[] arrayChar = userString.toCharArray(); //переводит введенный текст в симолы кода
        Arrays.sort(arrayChar); //сортирует символы по их значению
        System.out.println(arrayChar);
    }
}