import java.util.Arrays;
import java.util.Random;

public class Main {

    //2 Создайте случайно заполненный числовой массив, выведите его в консоль.
    // Найдите максимальное по модулю число в массиве и выведите его в консоль.

    public static void main(String[] args) {
        int[] arr = new int[15];
        Random rnd = new Random();
        System.out.println("Массив: ");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rnd.nextInt(-100, 100);
            System.out.print(arr[i] + " ");
        }
        int maxAbsValue = Math.abs(arr[0]);
        for (int i = 1; i < arr.length; i++) {
            if (Math.abs(arr[i]) > maxAbsValue) {
                maxAbsValue = Math.abs(arr[i]);
            }
        }
        System.out.println("Максимальное по модулю число: " + maxAbsValue);
    }
}